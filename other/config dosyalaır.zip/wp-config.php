<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */

define( 'DB_NAME', 'test_summitv2' );

/** MySQL database username */
define( 'DB_USER', 'test_summitU' );

/** MySQL database password */
define( 'DB_PASSWORD', 'LrFP9VN8SF4x' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
 
define('AUTH_KEY',         'e)FosNMy/7Y#fY|2eR;.9feGL;>^f ?,!mqgfR|&0j0!xGM}oApL0uSX#sU>kc;m');

define('SECURE_AUTH_KEY',  ');2r7>5/!<t-+!kCScC]l,iqGWDEWFV6RrOrpv^6RwGv?nu&~=<EM:Kb_1$(jqG$');

define('LOGGED_IN_KEY',    'O8ek})(SwFp]s^4M|<iOA#GB|O`%Lfo&8yu-q6sQg(Pzfv0/u]AY^8T7E)I>kq0!');

define('NONCE_KEY',        ']OnD41K|D3fo6yq1_^ t-?PGJo{Ebg%k1.%=uR<2@)rlyTobD|N{XNSVWeN,DU6$');

define('AUTH_SALT',        'OZ/X-bDD0%i!sOWG&qyPexY3|,mZUpB!V N|bu=v*]i+(LsM9IhL=5=/k7bQT[HS');

define('SECURE_AUTH_SALT', ']gI|[,3F&E<@FXG.m@crZK*Z+.`gI8bL@US.6zF%QoRmu!IteC-}ZV*BZ*DPIkbm');

define('LOGGED_IN_SALT',   '4hSXf|c?_2(t%2N,V|E~>->N0Q)i(lFD#C+n!wvgKG-~Sgh2dT;:iTo3+I^wl-&@');

define('NONCE_SALT',       'H(OMuUq^w=xJiW+E?m:!UQSA{L4@E,lyq#g<O,7yh7KT3q9;*hnR?E]}81cy|X[s');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
